# ============================================================
# §5 — Does the galactic scale follow the expansion rate? (redshift test)
#
# g† = cH0/2π today (§5). Two readings of "set by the cosmic vacuum":
#   expansion reading  g†(z) = cH(z)/2π      → grows into the past   (R = 1)
#   vacuum reading     g† tracks ρ_vac        → nearly constant        (R = 0)
# Statistic: R = ln[g†(z)/g†_local] / ln[H(z)/H0], local scale measured the same way on SPARC.
# Rule (fixed before running, same as the original pre-registration):
#   expansion reading favoured if |R−1| < 2σ and |R| > 2σ; vacuum reading if the reverse; else inconclusive.
#
# Data (public; transcribed rows in data_included/highz/, checked row by row against each
# catalogue's own f_DM — largest mismatch 0.04):
#   Price et al. 2021 (41 discs, z 0.7–2.5): f_DM(R_e) and baryonic masses
#   KROSS (first 42 rows of the catalogue, z ≈ 0.9), KMOS3D (41, z 0.7–2.2), KGES (21, z 1.3–1.6):
#   rotation speed and enclosed baryonic mass at R_out = 2.95 R_e (Zenodo record 15458539)
# Z1–Z4 TEST per sample; Z5 TEST combined (inverse-variance).
# ============================================================
import glob
from scipy.special import i0 as _i0, i1 as _i1, k0 as _k0, k1 as _k1
print("── §5: redshift test of g† ───────────────────────")
HZD = next((c for c in (os.path.join(os.path.dirname(os.path.abspath(sys.argv[0])), "data_included", "highz"),
                         os.path.join(os.getcwd(), "data_included", "highz")) if os.path.isdir(c)), None)
_Om = 0.315
_E = lambda z: math.sqrt(_Om * (1 + z)**3 + 1 - _Om)
_law = lambda gb, gd: gb / (1 - np.exp(-np.sqrt(gb / gd)))
_rng = np.random.default_rng(7)
def _verdict(R, s):
    if abs(R - 1) < 2 * s and abs(R) > 2 * s: return "expansion reading favoured"
    if abs(R) < 2 * s and abs(R - 1) > 2 * s: return "vacuum reading favoured"
    return "inconclusive"
def _rows(fn):
    return [l.strip() for l in open(os.path.join(HZD, fn), encoding="utf-8") if l.strip() and not l.startswith("#")]
_TAB = {}
for l in (DATA / "SPARC_Lelli2016c.mrt").read_text(encoding="utf-8", errors="ignore").splitlines():
    p = l.split()
    if len(p) >= 18:
        try: _TAB[p[0]] = dict(L=float(p[7]), Reff=float(p[9]), Rd=float(p[11]), MHI=float(p[13]), inc=float(p[5]), Q=int(p[17]))
        except ValueError: pass
def _sparc_curves():
    for fn in sorted((DATA / "sparc").glob("*_rotmod.dat")):
        t = _TAB.get(fn.stem.replace("_rotmod", ""))
        if not t or t["Q"] >= 3 or t["inc"] < 30 or t["Reff"] <= 0 or t["Rd"] <= 0: continue
        d = np.array([[float(x) for x in l.split()[:6]] for l in fn.read_text(encoding="utf-8").splitlines() if l.strip() and not l.startswith("#")])
        yield t, d
G_, MS_, KP_ = 6.674e-11, 1.989e30, 3.0857e19
# ── Method A (Price+21): one point at R_e, f_DM → g† = g_bar/(ln f)², thin exponential disc
def _disc_gbar(Mb, Re):
    Rd = Re / 1.678; y = Re / (2 * Rd); Sig0 = Mb * MS_ / (2 * math.pi * (Rd * KP_)**2)
    return 4 * math.pi * G_ * Sig0 * Rd * KP_ * y**2 * (_i0(y) * _k0(y) - _i1(y) * _k1(y)) / (Re * KP_)
hzA = []
for l in _rows("price21.txt"):
    p = l.split(); z, Mb, Re, f = float(p[1]), 10**float(p[4]), float(p[5]), float(p[6])
    if 0.02 < f < 0.98: hzA.append((math.log(_E(z)), math.log(_disc_gbar(Mb, Re) / math.log(f)**2)))
hzA = np.array(hzA)
locA = []
for t, d in _sparc_curves():
    if not (d[:, 0].min() <= t["Reff"] <= d[:, 0].max()): continue
    Mb = (0.5 * t["L"] + 1.33 * t["MHI"]) * 1e9
    if math.log10(Mb) < 10.3: continue
    gb = _disc_gbar(Mb, t["Reff"]); go = (np.interp(t["Reff"], d[:, 0], d[:, 1]) * 1e3)**2 / (t["Reff"] * KP_)
    f = 1 - gb / go
    if 0.02 < f < 0.98: locA.append(math.log(gb / math.log(f)**2))
locA = np.array(locA)
def _RA(h, l):
    return float((h[:, 0] * (h[:, 1] - l.mean())).sum() / (h[:, 0]**2).sum())
RA = _RA(hzA, locA)
sA = float(np.std([_RA(hzA[_rng.integers(0, len(hzA), len(hzA))], locA[_rng.integers(0, len(locA), len(locA))]) for _ in range(4000)]))
# ── Method B (catalogues): rotation speed and enclosed baryons at R_out; g† fitted with the §5 law
def _fit(gb, go):
    def nll(x):
        t_ = math.exp(x[1]); r = np.log10(go) - np.log10(_law(gb, 10**x[0]))
        return 0.5 * np.sum(r**2 / t_**2 + 2 * math.log(t_))
    return min((minimize(nll, [s0, math.log(0.15)], method="Nelder-Mead") for s0 in (-10.5, -10, -9.5)), key=lambda r: r.fun).x[0] * math.log(10)
locB = []
for t, d in _sparc_curves():
    R = 2.95 * t["Reff"]
    if not (d[:, 0].min() <= R <= d[:, 0].max()): continue
    x = R / t["Rd"]; Menc = (0.5 * t["L"] + 1.33 * t["MHI"]) * 1e9 * (1 - (1 + x) * math.exp(-x))
    locB.append((G_ * Menc * MS_ / (R * KP_)**2, (np.interp(R, d[:, 0], d[:, 1]) * 1e3)**2 / (R * KP_), math.log10(Menc)))
locB = np.array(locB)
def _load(fn):
    o = []
    for l in _rows(fn):
        p = l.split(","); z, R, V, M = float(p[1]), float(p[2]), float(p[3]), float(p[4])
        o.append((z, G_ * M * MS_ / (R * KP_)**2, (V * 1e3)**2 / (R * KP_), math.log10(M)))
    return np.array(o)
def _RB(h, L):
    return (_fit(h[:, 1], h[:, 2]) - _fit(L[:, 0], L[:, 1])) / math.log(_E(float(np.median(h[:, 0]))))
ZRES = [("Price+21", len(hzA), "0.7–2.5", RA, sA)]
record("Z1", "TEST", "Redshift test, Price+21 (41 discs; f_DM at R_e; mass-matched local anchor)",
       f"R = {RA:+.2f} ± {sA:.2f}", rule="expansion reading if |R−1|<2σ and |R|>2σ; vacuum reading if reverse", passed=None,
       note=_verdict(RA, sA))
for tid, nm, fn in (("Z2", "KROSS", "kross_rout.csv"), ("Z3", "KMOS3D", "kmos3d_rout.csv"), ("Z4", "KGES", "kges_rout.csv")):
    h = _load(fn); lo, hi = np.percentile(h[:, 3], [10, 90]); L = locB[(locB[:, 2] >= lo) & (locB[:, 2] <= hi)]
    R = _RB(h, L)
    s = float(np.std([_RB(h[_rng.integers(0, len(h), len(h))], L[_rng.integers(0, len(L), len(L))]) for _ in range(300)]))
    ZRES.append((nm, len(h), f"{h[:, 0].min():.1f}–{h[:, 0].max():.1f}", R, s))
    record(tid, "TEST", f"Redshift test, {nm} ({len(h)} discs; V and baryons at R_out; mass-matched local anchor)",
           f"R = {R:+.2f} ± {s:.2f}", rule="as Z1", passed=None, note=_verdict(R, s))
w = np.array([1 / s**2 for *_, s in ZRES]); Rv = np.array([r[3] for r in ZRES])
Rc = float((w * Rv).sum() / w.sum()); sc = float(1 / math.sqrt(w.sum())); chi = float((w * (Rv - Rc)**2).sum())
for nm, n, zr, R, s in ZRES: print(f"  {nm:8s} n={n:2d} z={zr}  R = {R:+.2f} ± {s:.2f}  → {_verdict(R, s)}")
print(f"  combined: R = {Rc:+.2f} ± {sc:.2f} ({abs(Rc)/sc:.1f}σ from 0, {abs(Rc-1)/sc:.1f}σ from 1) → {_verdict(Rc, sc)}; χ² = {chi:.1f} / {len(ZRES)-1} dof")
record("Z5", "TEST", "The galactic scale follows the expansion rate, g†(z) = cH(z)/2π (four samples combined)",
       f"R = {Rc:+.2f} ± {sc:.2f}: {abs(Rc-1)/sc:.1f}σ from the expansion reading, {abs(Rc)/sc:.1f}σ from the vacuum reading",
       rule="|R−1| < 2σ and |R| > 2σ", passed=bool(abs(Rc - 1) < 2 * sc and abs(Rc) > 2 * sc),
       note=f"{_verdict(Rc, sc)}. The samples disagree with each other (χ² = {chi:.1f} for {len(ZRES)-1} dof): Price+21 points to growth, the three "
            "catalogues with measured rotation speeds do not. High-redshift discs are turbulent and pressure-supported; several catalogue "
            "galaxies have baryons exceeding their dynamical mass, so this systematic is not excluded. The expansion reading is "
            "excluded; the vacuum reading (a nearly constant scale, set by the slowly changing vacuum density) is consistent but "
            "unconfirmed. MOND postulates a constant scale; the data cannot yet tell the two apart.")
