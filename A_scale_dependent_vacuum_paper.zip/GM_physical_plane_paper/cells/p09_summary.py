# ============================================================
# Summary — every result, its kind, and its rule
# ============================================================
print("── Summary ───────────────────────────────────────────")
print(f"  {'id':5s} {'kind':11s} {'status':6s}  claim")
for r in RESULTS:
    st = {True: "PASS", False: "FAIL", None: "—"}[r["passed"]]
    print(f"  {r['test']:5s} {r['kind']:11s} {st:6s}  {r['claim']}")
    print(f"  {'':5s} {'':11s} {'':6s}  → {r['value']}")
kinds = {}
for r in RESULTS:
    key = (r["kind"], {True: "pass", False: "fail", None: "n/a"}[r["passed"]])
    kinds[key] = kinds.get(key, 0) + 1
print("\n  Tally: " + ", ".join(f"{k[0]} {k[1]}: {v}" for k, v in sorted(kinds.items())))
report = {"generated_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
          "provenance": PROVENANCE, "results": RESULTS}
(RES / "paper_results.json").write_text(json.dumps(report, indent=2, default=str))
print(f"\n  written: {RES/'paper_results.json'}")
