# ============================================================
# §5 — Galaxies (SPARC): the acceleration scale g†
#
# v1 computed g_obs/g† and never used the baryonic columns.
# v2 fits the radial acceleration relation g_obs(g_bar) point by point.
#
#   g_bar = (V_gas|V_gas| + Υd V_disk|V_disk| + Υb V_bul|V_bul|) / r
#   g_obs = V_obs² / r
#
# Models (fit in log10 g_obs, intrinsic scatter τ free):
#   M0  Newton            g = g_bar
#   M1  GM-linear (v1)    g = g_bar + a_c          ⇔ v² = v_bar² + a_c r
#   M2  RAR (McGaugh+16)  g = g_bar / (1 − exp(−√(g_bar/g†)))
#   M3  simple-ν MOND     g = g_bar (1 + √(1 + 4g†/g_bar)) / 2
#   M2* RAR with g† FIXED to the GM value cH0/2π  (zero free scale)
#
# Pre-registered pass rules:
#   T1a  |log g†_fit − log(cH0/2π)| < 2σ_tot   (σ_tot = bootstrap ⊕ Υ-sys ⊕ H0-sys)
#   T1b  GM-linear (M1) not disfavoured: BIC(M1) − BIC(best) < 10
# ============================================================
from scipy.optimize import minimize

UPS_D, UPS_B = 0.5, 0.7           # 3.6μm mass-to-light (Lelli+16 / McGaugh+16 convention)
ACC = 1e6 / KPC_M                 # (km/s)²/kpc → m/s²
LN10 = math.log(10)

def load_sparc():
    gals = {}
    for f in sorted((DATA / "sparc").glob("*_rotmod.dat")):
        rows = []
        for line in f.read_text(encoding="utf-8").splitlines():
            p = line.split()
            if not p or line.lstrip().startswith("#") or len(p) < 6:
                continue
            try:
                rows.append([float(v) for v in p[:6]])
            except ValueError:
                pass
        if rows:
            gals[f.stem.replace("_rotmod", "")] = np.array(rows)
    return gals

def load_quality():
    f = DATA / "SPARC_Lelli2016c.mrt"
    if not f.exists():
        return None
    q = {}
    for line in f.read_text(encoding="utf-8", errors="ignore").splitlines():
        p = line.split()
        if len(p) >= 18:
            try:
                q[p[0]] = {"T": int(p[1]), "D": float(p[2]), "eD": float(p[3]), "inc": float(p[5]),
                           "einc": float(p[6]), "Rdisk": float(p[11]), "SBdisk": float(p[12]),
                           "Vflat": float(p[15]), "Q": int(p[17])}
            except ValueError:
                pass
    return q or None

def build_points(gals, quality, ups_d=UPS_D, ups_b=UPS_B):
    G = {"gbar": [], "gobs": [], "sig": [], "gal": [], "r": [], "v": [], "vbar2": []}
    used = 0
    for name, d in gals.items():
        if quality is not None:
            qq = quality.get(name)
            if qq is None or qq["Q"] >= 3 or qq["inc"] < 30:
                continue
        r, v, ev, vg, vd, vb = d.T
        vbar2 = vg * np.abs(vg) + ups_d * vd * np.abs(vd) + ups_b * vb * np.abs(vb)
        m = (r > 0) & (v > 0) & (ev > 0) & (vbar2 > 0) & (ev / v < 0.5)
        if m.sum() < 3:
            continue
        used += 1
        G["gbar"].append(vbar2[m] / r[m] * ACC)
        G["gobs"].append(v[m]**2 / r[m] * ACC)
        G["sig"].append(2 * ev[m] / v[m] / LN10)
        G["gal"].append(np.full(m.sum(), used - 1))
        G["r"].append(r[m]); G["v"].append(v[m]); G["vbar2"].append(vbar2[m])
    out = {k: np.concatenate(v) for k, v in G.items()}
    out["n_gal"] = used
    return out

MODELS = {
    "M0_newton":   (0, lambda gb, p: gb),
    "M1_gm_linear":(1, lambda gb, p: gb + 10**p[0]),
    "M2_rar":      (1, lambda gb, p: gb / (1 - np.exp(-np.sqrt(gb / 10**p[0])))),
    "M3_simple_nu":(1, lambda gb, p: gb * (1 + np.sqrt(1 + 4 * 10**p[0] / gb)) / 2),
}

def nll(params, model, P, fixed_logg=None):
    k, f = MODELS[model]
    pm = [fixed_logg] if fixed_logg is not None else list(params[:k])
    tau = math.exp(params[-1])
    with np.errstate(over="ignore", invalid="ignore"):
        pred = np.log10(f(P["gbar"], pm))
    if not np.all(np.isfinite(pred)):
        return 1e30
    var = P["sig"]**2 + tau**2
    return 0.5 * np.sum((np.log10(P["gobs"]) - pred)**2 / var + np.log(var))

def fit(model, P, fixed_logg=None):
    k, _ = MODELS[model]
    nfree = (0 if fixed_logg is not None else k) + 1
    best = None
    for lg0 in ([-10.0, -9.5, -10.5] if nfree == 2 else [None]):
        x0 = ([lg0] if nfree == 2 else []) + [math.log(0.1)]
        r = minimize(nll, x0, args=(model, P, fixed_logg), method="Nelder-Mead",
                     options={"xatol": 1e-6, "fatol": 1e-6, "maxiter": 4000})
        if best is None or r.fun < best.fun:
            best = r
    n = len(P["gobs"])
    return {"params": best.x.tolist(), "nll": float(best.fun),
            "BIC": float(2 * best.fun + nfree * math.log(n)), "k": nfree,
            "tau_dex": float(math.exp(best.x[-1]))}

def outer_slopes(P, a_c=None):
    """median d ln v / d ln r over the outer half of each curve (observed, and M1 model)"""
    so, sm = [], []
    for gi in range(P["n_gal"]):
        m = P["gal"] == gi
        r, v = P["r"][m], P["v"][m]
        o = r > 0.5 * r.max()
        if o.sum() < 3:
            continue
        so.append(np.polyfit(np.log(r[o]), np.log(v[o]), 1)[0])
        if a_c is not None:
            vm = np.sqrt(P["vbar2"][m][o] + a_c / ACC * r[o])
            sm.append(np.polyfit(np.log(r[o]), np.log(vm), 1)[0])
    return float(np.median(so)), (float(np.median(sm)) if sm else None), len(so)

print("── §5: SPARC radial acceleration relation ───────")
GALS = load_sparc()
QUAL = load_quality()
T1 = {}
if len(GALS) < 50:
    record("G1", "TEST", "Galaxy test NOT RUN — SPARC rotation curves missing",
           f"{len(GALS)} curves on disk", passed=None,
           note="Rerun Part 0 where zenodo is reachable (Colab is), then rerun this cell.")
else:
    P = build_points(GALS, QUAL)
    print(f"  galaxies used: {P['n_gal']}  points: {len(P['gobs'])}  "
          f"quality cuts: {'Q<3, i≥30°' if QUAL else 'none (table missing)'}")
    fits = {m: fit(m, P) for m in MODELS}
    lg_pred = {H0: math.log10(G_DAG(H0)) for H0 in (67.4, 73.0)}
    fits["M2star_fixed_gm"] = fit("M2_rar", P, fixed_logg=lg_pred[67.4])
    bic_best = min(f["BIC"] for f in fits.values())
    for m, f in fits.items():
        sc = f"log g = {f['params'][0]:.3f}" if f["k"] == 2 else ""
        print(f"  {m:18s} ΔBIC = {f['BIC'] - bic_best:9.1f}   τ = {f['tau_dex']:.3f} dex  {sc}")

    # uncertainty on g† (M2): bootstrap over galaxies + Υ systematic
    rng = np.random.default_rng(1)
    boot = []
    for _ in range(int(os.environ.get("GM_NBOOT", 200))):
        pick = rng.integers(0, P["n_gal"], P["n_gal"])
        idx = np.concatenate([np.where(P["gal"] == g)[0] for g in pick])
        Pb = {k2: P[k2][idx] for k2 in ("gbar", "gobs", "sig")}
        boot.append(fit("M2_rar", Pb)["params"][0])
    sig_boot = float(np.std(boot))
    ups_fits = [fit("M2_rar", build_points(GALS, QUAL, ups_d=u, ups_b=u + 0.2))["params"][0]
                for u in (0.4, 0.6)]
    sig_ups = float(abs(ups_fits[1] - ups_fits[0]) / 2)
    sig_h0 = abs(lg_pred[73.0] - lg_pred[67.4]) / 2
    sig_tot = math.sqrt(sig_boot**2 + sig_ups**2 + sig_h0**2)
    lg_fit = fits["M2_rar"]["params"][0]
    lg_mid = (lg_pred[67.4] + lg_pred[73.0]) / 2
    nsig = abs(lg_fit - lg_mid) / sig_tot
    print(f"\n  g†(fit, RAR)   = {10**lg_fit:.3e} m/s²  (±{sig_boot:.3f} boot, ±{sig_ups:.3f} Υ, dex)")
    print(f"  g†(GM)=cH0/2π  = {10**lg_pred[67.4]:.3e} – {10**lg_pred[73.0]:.3e} m/s²")
    print(f"  ratio fit/GM   = {10**(lg_fit - lg_mid):.3f}   →  {nsig:.2f} σ")
    record("G1a", "TEST", "RAR acceleration scale g† equals cH0/2π",
           f"{10**lg_fit:.3e} vs {10**lg_mid:.3e} m/s² ({nsig:.2f}σ)",
           rule="< 2σ_tot", passed=bool(nsig < 2))

    d_lin = fits["M1_gm_linear"]["BIC"] - bic_best
    s_obs, s_m1, n_sl = outer_slopes(P, a_c=10**fits["M1_gm_linear"]["params"][0])
    print(f"  outer-curve slope dlnv/dlnr: observed {s_obs:+.3f} | GM-linear model {s_m1:+.3f} ({n_sl} galaxies)")
    record("T1b", "SUPERSEDED", "Original preprint's linear law v² = v_bar² + a_c r (M1) not disfavoured",
           f"ΔBIC = {d_lin:+.1f}; outer-curve slope observed {s_obs:+.3f} vs M1 {s_m1:+.3f}",
           rule="BIC(M1) − BIC(best) < 10", passed=bool(d_lin < 10),
           note="The formula of the original preprint, kept with its pre-set rule and outcome. Replaced by the "
                "vacuum-gradient field (GF1–GF3).")
    record("G1c", "DIAGNOSTIC", "Cost of fixing g† to cH0/2π (M2* vs M2)",
           f"ΔBIC = {fits['M2star_fixed_gm']['BIC'] - fits['M2_rar']['BIC']:.1f}")
    # ── Robustness: stellar mass-to-light and data cuts ──────
    print("\n  robustness (RAR g† refit):")
    def _sub(P0, m):
        Q = {k3: P0[k3][m] for k3 in ("gbar", "gobs", "sig", "gal", "r", "v", "vbar2")}
        u = np.unique(Q["gal"]); rm = {g: i for i, g in enumerate(u)}
        Q["gal"] = np.array([rm[g] for g in Q["gal"]]); Q["n_gal"] = len(u)
        return Q
    npts = np.bincount(P["gal"])
    variants = {f"Υd={u:.1f}": build_points(GALS, QUAL, ups_d=u, ups_b=u + 0.2) for u in (0.3, 0.4, 0.6, 0.7)}
    variants.update({"errV/V<0.1": _sub(P, P["sig"] * LN10 / 2 < 0.1),
                     "r>1 kpc": _sub(P, P["r"] > 1.0),
                     "≥10 pts/galaxy": _sub(P, npts[P["gal"]] >= 10)})
    ROB = {}
    for nm, Pv in variants.items():
        fv = fit("M2_rar", Pv)
        ROB[nm] = 10**fv["params"][0]
        print(f"    {nm:16s} n_gal={Pv['n_gal']:3d}  g† = {ROB[nm]:.3e}")
    cuts = [ROB[k3] for k3 in ("errV/V<0.1", "r>1 kpc", "≥10 pts/galaxy")] + [10**lg_fit]
    record("G1d", "DIAGNOSTIC", "g† stability under data cuts (Υd = 0.5)",
           f"{min(cuts):.2e} – {max(cuts):.2e} m/s²")
    record("G1e", "DIAGNOSTIC", "g† degeneracy with stellar mass-to-light Υd (0.3 → 0.7)",
           f"{ROB['Υd=0.3']:.2e} → {ROB['Υd=0.7']:.2e} m/s²",
           note="The match to cH0/2π holds at the conventional Υd = 0.5; Υ must be pinned independently "
                "(e.g. stellar population models) for the match to be sharp.")
    d_vs_mond = {}
    for u, Pu in ((0.4, variants["Υd=0.4"]), (0.5, P), (0.6, variants["Υd=0.6"])):
        bg = fit("M2_rar", Pu, fixed_logg=lg_pred[67.4])["BIC"]
        bm = fit("M2_rar", Pu, fixed_logg=math.log10(1.2e-10))["BIC"]
        d_vs_mond[u] = bg - bm
    flips = (min(d_vs_mond.values()) < 0) and (max(d_vs_mond.values()) > 0)
    record("G1f", "DIAGNOSTIC", "Can rotation curves alone separate g† = cH0/2π from MOND's a0 = 1.2×10⁻¹⁰ m/s²?",
           "ΔBIC(GM − MOND) at Υd = " + ", ".join(f"{u}: {v:+.1f}" for u, v in d_vs_mond.items()),
           note=("No: the preference flips sign with the stellar mass-to-light ratio. " if flips else
                 "The preference keeps one sign across Υd = 0.4–0.6. ")
                + "The test that separates them is the redshift dependence g†(z) (P1).")
    T1 = {"robustness_g_dag": ROB, "dBIC_gm_vs_mond_fixed": d_vs_mond,
          "n_gal": P["n_gal"], "n_pts": int(len(P["gobs"])), "fits": fits,
          "g_dag_fit": 10**lg_fit, "sig_dex": {"boot": sig_boot, "ups": sig_ups, "H0": sig_h0},
          "g_dag_gm": {str(k3): 10**v3 for k3, v3 in lg_pred.items()},
          "outer_slope": {"obs": s_obs, "M1": s_m1}}
    (RES / "test01_galaxies.json").write_text(json.dumps(T1, indent=2))


# ============================================================
# ============================================================
# Likelihood machinery for SPARC with per-galaxy nuisances (stellar mass-to-light,
# distance, inclination marginalised on grids). Used by the field test GF3 below.
# ============================================================
from scipy.special import logsumexp

DGRID = np.linspace(-0.3, 0.3, 13)
LOGPRIOR = -0.5 * (DGRID / 0.1)**2
LOGPRIOR -= logsumexp(LOGPRIOR)

def build_components(gals, use_quality=True):
    out = {"vg2": [], "vs2": [], "r": [], "gobs": [], "sig": [], "gal": [], "v": [], "sG": []}
    gi = 0
    for name, d in gals.items():
        sG = 0.0
        if QUAL is not None and use_quality:
            qq = QUAL.get(name)
            if qq is None or qq["Q"] >= 3 or qq["inc"] < 30:
                continue
            inc = math.radians(qq["inc"])
            sG = math.hypot(qq["eD"] / (qq["D"] * LN10),
                            2 / math.tan(inc) * math.radians(qq["einc"]) / LN10)
        r, v, ev, vg, vd, vb = d.T
        vg2 = vg * np.abs(vg)
        vs2 = UPS_D * vd * np.abs(vd) + UPS_B * vb * np.abs(vb)
        gmin = np.minimum(vg2 + 10**DGRID[0] * vs2, vg2 + 10**DGRID[-1] * vs2)
        m = (r > 0) & (v > 0) & (ev > 0) & (gmin > 0) & (ev / v < 0.5)
        if m.sum() < 3:
            continue
        for k2, val in (("vg2", vg2[m]), ("vs2", vs2[m]), ("r", r[m]), ("v", v[m]),
                        ("gobs", v[m]**2 / r[m] * ACC), ("sig", 2 * ev[m] / v[m] / LN10)):
            out[k2].append(val)
        out["gal"].append(np.full(m.sum(), gi)); out["sG"].append(np.full(m.sum(), sG)); gi += 1
    C = {k2: np.concatenate(v) for k2, v in out.items()}
    C["n_gal"] = gi
    C["starts"] = np.r_[0, np.flatnonzero(np.diff(C["gal"])) + 1]
    C["gbar_grid"] = np.array([(C["vg2"] + 10**d_ * C["vs2"]) / C["r"] * ACC for d_ in DGRID])
    C["ly"] = np.log10(C["gobs"])
    C["sG_gal"] = C["sG"][C["starts"]]
    return C

def model_s(gb, s_, lg, lm):
    m_ = 10**lm
    return np.log10(gb) + (s_ / m_) * np.log10(1 + (10**lg / gb)**m_)

def marg_nll(pred, lt, C):
    """−log L with Υ (grid) and distance/inclination (analytic) marginalised per galaxy"""
    var = C["sig"]**2 + math.exp(lt)**2
    R = C["ly"] - pred
    w = 1 / var
    A = np.add.reduceat(R**2 * w, C["starts"], axis=1)                    # (grid, n_gal)
    B = np.add.reduceat(R * w, C["starts"], axis=1)
    W = np.add.reduceat(w, C["starts"])                                    # (n_gal,)
    LD = np.add.reduceat(np.log(2 * math.pi * var), C["starts"])
    s2 = C["sG_gal"]**2
    chi = A - np.where(s2 > 0, B**2 * s2 / (1 + s2 * W), 0.0)               # Sherman–Morrison
    Lg = -0.5 * (chi + LD + np.log1p(s2 * W))
    return -float(np.sum(logsumexp(Lg + LOGPRIOR[:, None], axis=0)))

def negloglike(theta, C, fixed=None):
    th = dict(zip(("s", "lg", "lm", "lt"), theta))
    if fixed: th.update(fixed)
    if not (0.0 <= th["s"] <= 1.0 and -11.5 < th["lg"] < -8.5 and -0.7 < th["lm"] < 0.7 and -6 < th["lt"] < 0):
        return 1e30
    pred = model_s(C["gbar_grid"], th["s"], th["lg"], th["lm"])            # (grid, N)
    return marg_nll(pred, th["lt"], C)

def fit_s(C, fixed=None, starts=None):
    names = [n_ for n_ in ("s", "lg", "lm", "lt") if not (fixed and n_ in fixed)]
    base = {"s": 0.45, "lg": -10.0, "lm": 0.0, "lt": math.log(0.1)}
    best = None
    for st in (starts or [{}, {"s": 0.3, "lg": -9.8}, {"s": 0.6, "lg": -10.2, "lm": 0.3}]):
        x0 = [{**base, **st}[n_] for n_ in names]
        r_ = minimize(lambda x: negloglike(x, C, fixed) if not fixed else
                      negloglike([dict(zip(names, x), **fixed)[k3] for k3 in ("s", "lg", "lm", "lt")], C),
                      x0, method="Nelder-Mead", options={"xatol": 1e-5, "fatol": 1e-4, "maxiter": 5000})
        if best is None or r_.fun < best.fun:
            best = r_
    out = dict(zip(names, map(float, best.x)))
    if fixed: out.update(fixed)
    out["nll"] = float(best.fun)
    return out

print("── SPARC likelihood with nuisances ───────────────────")
S_FIT = {}
if len(GALS) >= 50:
    C = build_components(GALS)


# ============================================================
# §5 — The vacuum-gradient mechanism as a field equation
# Mechanism: outside a galaxy the vacuum is unrelaxed (strong); inside, matter relaxes it. The gradient from
# outside to inside produces the apparent unseen mass.
# Field form [constructed here, labelled]: let r(y) ∈ [0,1] be the relaxed fraction of the vacuum where the matter's own
# pull is g_N = y g†. The vacuum's unrelaxed part acts on matter through its gradient:
#     ∇²Φ = 4πGρ + ∇·[ (ν(y) − 1) ∇Φ_N ],   ν(y) = 1 / r(y)
# so the unseen mass density is ρ_ph = ∇·[(ν−1)g_N]/4πG — literally a divergence (gradient) of the unrelaxed vacuum.
# Relaxation law: r(y) = 1 − exp(−√y). It must be ≈1 where matter dominates (y ≫ 1) and must give the scale-invariant
# deep limit: r ≈ √y for y ≪ 1. The exponential is the simplest form with both limits (stated choice).
# GF1 DERIVED  limits: Newtonian where relaxed; deep limit scale-invariant (g → √(g_N g†), flat curves, v⁴ = GMg†).
# GF2 DERIVED  unseen mass grows outward: M_ph(<r)/M_b → 0 inside, → ∝ r outside (where the vacuum is unrelaxed).
# GF3 TEST     this field, g† FIXED to cH0/2π, on SPARC (spherical solution = algebraic law): ΔBIC vs the same law with g† free < 10.
# ============================================================
print("── §5: the vacuum-gradient field ───────────────────")
y_ = sp.Symbol("y", positive=True)
r_rel = 1 - sp.exp(-sp.sqrt(y_)); nu_ = 1 / r_rel
hi = sp.limit(nu_, y_, sp.oo); lo = sp.limit(nu_ * sp.sqrt(y_), y_, 0)
record("GF1", "DERIVED", "Vacuum-gradient field: relaxed (Newtonian) where matter dominates, scale-invariant where the vacuum is unrelaxed",
       f"ν(y→∞) = {hi}; ν(y→0)·√y = {lo} ⇒ g → √(g_N g†): flat curves, v⁴ = GMg†", rule="symbolic limits",
       passed=bool(hi == 1 and lo == 1),
       note="ρ_ph = ∇·[(ν−1)g_N]/4πG: the unseen mass is the divergence of the unrelaxed vacuum — the gradient, as an equation. "
            "Relaxation law r = 1 − e^{−√y} is a stated choice satisfying both required limits.")
rr_, M_, g_ = sp.symbols("r M g_dag", positive=True)
gN = M_ / rr_**2
Mph = sp.simplify((nu_.subs(y_, gN / g_) - 1) * M_)                       # phantom mass inside r (spherical, G = 1)
inner = sp.limit(Mph / M_, rr_, 0); outer = sp.limit(Mph / (rr_ * sp.sqrt(M_ * g_)), rr_, sp.oo)
record("GF2", "DERIVED", "Unseen mass grows outward, where the vacuum is less relaxed",
       f"M_ph/M_b → {inner} at small r; M_ph → {outer}·√(M g†)·r at large r", rule="symbolic limits",
       passed=bool(inner == 0 and outer == 1))
if len(GALS) >= 50:
    def nll_fixed(lt_, Cx, lg):
        gb = Cx["gbar_grid"]; return marg_nll(np.log10(lawB_s(gb, 10**lg)), lt_, Cx)
    def lawB_s(gb, gd): return gb / (1 - np.exp(-np.sqrt(gb / gd)))
    lg_fix = math.log10(G_DAG(67.4) * math.sqrt(73.0 / 67.4))       # middle of the H0 band
    bfix = minimize(lambda x: nll_fixed(x[0], C, lg_fix), [math.log(0.1)], method="Nelder-Mead")
    bfree = minimize(lambda x: nll_fixed(x[1], C, x[0]) if -11 < x[0] < -9 else 1e30, [lg_fix, math.log(0.1)], method="Nelder-Mead")
    n_pts = len(C["ly"]); dB = (2 * bfix.fun + 1 * math.log(n_pts)) - (2 * bfree.fun + 2 * math.log(n_pts))
    record("GF3", "TEST", "Vacuum-gradient field with g† fixed to cH0/2π describes SPARC",
           f"ΔBIC(fixed − free) = {dB:+.1f}; free g† = {10**bfree.x[0]:.3e}", rule="ΔBIC < 10", passed=bool(dB < 10),
           note="Spherical solution (algebraic). Thin-disc corrections are a few percent and not computed here.")
