# ============================================================
# §6 — Running vacuum with cosmic chronometers added
#
# Claim tested: the cosmic vacuum changes as the cosmic slice moves along S (C1–C2, ν > 0).
# Added data: 17 cosmic-chronometer H(z) points (BC03 calibration), as tabulated in
# A&A 614, A127 (2018), Table 2; error = stat ⊕ syst, diagonal (correlated systematics
# not modelled — stated limitation).
# RC1 TEST  Rule (stated before running): with CC added, the 2σ interval on ν still reaches ν ≥ 0.
# RC2 DIAG  ν and its significance with CC added, vs C2 without.
# ============================================================
print("── §6: running vacuum + cosmic chronometers ─────────")
CCD = np.array([(0.179,75.0,3.8,0.5),(0.199,75.0,4.9,0.6),(0.240,79.7,2.3,1.3),(0.352,83.0,13.0,4.8),(0.380,83.0,4.3,12.9),
                (0.400,77.0,2.1,10.0),(0.420,86.4,3.3,1.7),(0.425,87.1,2.4,11.0),(0.450,92.8,4.5,12.1),(0.478,80.9,2.1,8.8),
                (0.593,104.0,11.6,4.5),(0.680,92.0,6.4,4.3),(0.781,105.0,9.4,6.1),(0.875,125.0,15.3,6.0),(1.037,154.0,13.6,14.9),
                (1.363,160.0,22.1,24.0),(1.965,186.5,40.9,28.0)])
cc_z, cc_H, cc_e = CCD[:, 0], CCD[:, 1], np.hypot(CCD[:, 2], CCD[:, 3])
_tc_base = total_chi2
def total_chi2(p, sets):                                   # noqa: F811 — adds the CC likelihood
    c = _tc_base(p, tuple(s_ for s_ in sets if s_ != "CC"))
    if "CC" in sets and c < 1e9:
        c += float(np.sum(((100 * p["h"] * E(cc_z, p) - cc_H) / cc_e)**2))
    return c
SETS4 = ("SN", "BAO", "CMB", "CC")
l4 = fit_cosmo("lcdm", SETS4); r4 = fit_cosmo("rvm", SETS4, starts=[None, {"nu": 0.002}, {"nu": -0.001}])
bf4 = r4["params"]; grid4 = np.round(np.arange(-0.004, 0.0081, 0.0005), 6); prof4 = []
for nv in grid4:
    f = fit_cosmo("rvm", SETS4, fixed={"nu": float(nv)}, starts=[{k: v for k, v in bf4.items() if k != "nu"}])
    prof4.append(f["chi2"])
prof4 = np.array(prof4); fine4 = np.linspace(grid4[0], grid4[-1], 4001); pf4 = np.interp(fine4, grid4, prof4); pf4 -= pf4.min()
nu4 = float(fine4[np.argmin(pf4)]); s1 = (fine4[pf4 <= 1].min(), fine4[pf4 <= 1].max()); s2 = (fine4[pf4 <= 4].min(), fine4[pf4 <= 4].max())
sig4 = nu4 / ((s1[1] - s1[0]) / 2)
print(f"  ν = {nu4:+.5f}, 2σ [{s2[0]:+.5f}, {s2[1]:+.5f}]  ({sig4:.1f}σ);  ΔAIC = {r4['chi2'] + 2*r4['k'] - l4['chi2'] - 2*l4['k']:+.2f}")
record("RC1", "TEST", "Running vacuum (ν > 0) survives with cosmic chronometers added (SN+BAO+CMB+CC)",
       f"ν = {nu4:+.5f}, 2σ [{s2[0]:+.5f}, {s2[1]:+.5f}]", rule="2σ interval reaches ν ≥ 0", passed=bool(s2[1] >= 0))
record("RC2", "DIAGNOSTIC", "Significance of ν > 0 with and without chronometers",
       f"with CC: {sig4:.1f}σ (ΔAIC {r4['chi2'] + 2*r4['k'] - l4['chi2'] - 2*l4['k']:+.2f}); without (C2): see C2",
       note="Chronometer errors are large; they mainly constrain H0 and Ωm. Correlated systematics not modelled.")
total_chi2 = _tc_base


# ============================================================
# §6 — The S-ceiling: "as S → S_ceiling, Λ_eff → 0" — the vacuum fades
#
# The framework: at the ceiling the Ethereal Field dominates and Λ_eff → 0, K → 0. Heat death /
# "Big Rip" is the approach to the ceiling.
# Consequence tested: dark energy is fading today, i.e. its density decreases as the universe
# expands (w > −1 now). A cosmological constant (w = −1) or a growing dark energy (w < −1,
# needed for a Big Rip) would contradict "Λ_eff → 0".
# CE1 TEST   Rule (stated before running): CPL fit to SN+BAO+CMB+CC gives w0 > −1 at ≥ 2σ.
# CE2 DIAG   Internal consistency: "Λ_eff → 0" requires w > −1; a Big Rip requires w < −1.
# CE3 DIAG   GM's own late-time dynamics (S(t) driver, SD3): ρ_DE → 0 asymptotically — consistent with the ceiling.
# ============================================================
print("── §6: the S-ceiling ───────────────────────────────")
_tc0 = total_chi2
def total_chi2(p, sets):                                   # noqa: F811 (same CC likelihood as §6b)
    c = _tc0(p, tuple(s_ for s_ in sets if s_ != "CC"))
    if "CC" in sets and c < 1e9:
        c += float(np.sum(((100 * p["h"] * E(cc_z, p) - cc_H) / cc_e)**2))
    return c
S4 = ("SN", "BAO", "CMB", "CC")
wb_ = fit_cosmo("w0wa", S4, starts=[None, {"w0": -0.8, "wa": -0.7}, {"w0": -1.0, "wa": 0.0}])
pw = wb_["params"]; gw = np.round(np.arange(-1.15, -0.60, 0.025), 4); prw = []
for w0v in gw:
    f = fit_cosmo("w0wa", S4, fixed={"w0": float(w0v)}, starts=[{k: v for k, v in pw.items() if k != "w0"}, {"wa": 0.0}])
    prw.append(f["chi2"])
prw = np.array(prw); fw = np.linspace(gw[0], gw[-1], 3001); pfw = np.interp(fw, gw, prw); pfw -= pfw.min()
w0h = float(fw[np.argmin(pfw)]); w2 = (fw[pfw <= 4].min(), fw[pfw <= 4].max())
d_m1 = float(np.interp(-1.0, fw, pfw))
sig_w = math.sqrt(max(d_m1, 0))
print(f"  CPL: w0 = {w0h:+.3f}, wa = {pw['wa']:+.2f}; 2σ w0 ∈ [{w2[0]:+.3f}, {w2[1]:+.3f}]; w0 = −1 at Δχ² = {d_m1:.1f} ({sig_w:.1f}σ)")
record("CE1", "TEST", "S-ceiling: dark energy is fading today (w0 > −1)",
       f"w0 = {w0h:+.3f} (wa = {pw['wa']:+.2f}); w0 = −1 excluded at {sig_w:.1f}σ", rule="w0 > −1 at ≥ 2σ", passed=bool(sig_w >= 2 and w0h > -1),
       note="Profiled over all other parameters, SN+BAO+CMB+chronometers. The CPL form is a description, not GM's model.")
_ax = 1 - (-1 - pw["w0"]) / pw["wa"] if pw["wa"] != 0 else float("nan")
_zx = (1 / _ax - 1) if 0 < _ax < 1 else float("nan")
record("CE2", "DIAGNOSTIC", "Where the fitted CPL history crosses w = −1 (GM's S(t) cannot, I.8)",
       f"w0 = {pw['w0']:+.2f}, wa = {pw['wa']:+.2f}: w < −1 for z > {_zx:.2f}",
       note="Today's fading agrees with the ceiling; the fitted earlier phase below −1 is outside what GM's S(t) can do. "
            "GM's own model is tested directly in SD1.")
total_chi2 = _tc0


# ============================================================
# §6 — The S(t) driver
#
# I.6 already writes the cosmic slice as a field S(t) with kinetic weight α_S > 0 and a
# potential V(S). I.11 fixes the potential's shape: the slice vacuum scales as M_p²μ²
# with μ = μ0 e^{kS}, i.e.  V(S) ∝ e^{2kS}.  With the canonical field φ = √α_S·S
# (Planck units) this is an exponential potential  V = V0 e^{−λφ},  λ = 2k/√α_S.
# One new number, λ. Nothing else is chosen.
#
# Rules (stated before running):
#   SD1  The S(t) driver is not disfavoured vs ΛCDM on SN+BAO+CMB:  ΔAIC < 4.
#   SD2  Structural prediction (I.8): w ≥ −1 at all times (no phantom). Reported against
#        the CPL fit D5 as a DIAGNOSTIC.
#   SD3  Does the slice settle (constant vacuum, "why now" answered)? Exponential V has no
#        minimum, so it cannot settle; reported as DERIVED, with the late-time attractor.
#   SD4  Initial condition: the field must start where V ≈ ρ_Λ — reported as the
#        coincidence the driver does or does not remove.
# ============================================================
from scipy.integrate import solve_ivp
print("── §6: the S(t) driver ──────────────────────────────")
N0 = math.log(1e-5)
NG = np.linspace(N0, 0.0, 1200)

def _sd_solve(Om, Or, lam, v0):
    """φ'' + (3 + H'/H) φ' + V'/H² = 0 in N = ln a; units H0 = 1, M_p = 1; field frozen at early times."""
    def H2(N, ph, dph):
        rho = 3 * Om * np.exp(-3 * N) + 3 * Or * np.exp(-4 * N) + 3 * v0 * np.exp(-lam * ph)
        return rho / (3 - dph**2 / 2)
    def rhs(N, y):
        ph, dph = y; h2 = H2(N, ph, dph)
        eps = (3 * Om * np.exp(-3 * N) + 4 * Or * np.exp(-4 * N) + h2 * dph**2) / (2 * h2)
        return [dph, -(3 - eps) * dph + lam * 3 * v0 * np.exp(-lam * ph) / h2]
    sol = solve_ivp(rhs, (N0, 0.0), [0.0, 0.0], t_eval=NG, rtol=1e-7, atol=1e-10)
    ph, dph = sol.y
    return NG, H2(NG, ph, dph), ph, dph

def sd_table(Om, h, lam):
    Or = OMEGA_G_H2 * (1 + 0.2271 * NEFF) / h**2
    v0 = 1 - Om - Or                                   # shoot v0 so that H(a=1) = H0 (secant)
    va, fa = v0, _sd_solve(Om, Or, lam, v0)[1][-1] - 1
    vb = v0 * 1.05; fb = _sd_solve(Om, Or, lam, vb)[1][-1] - 1
    for _ in range(12):
        if abs(fb) < 1e-9 or fb == fa: break
        va, vb, fa = vb, vb - fb * (vb - va) / (fb - fa), fb
        fb = _sd_solve(Om, Or, lam, vb)[1][-1] - 1
    return _sd_solve(Om, Or, lam, vb), vb

_E_base2 = E
_SD_CACHE = {}
def E(z, p):                                           # noqa: F811
    if p["model"] != "sdriver":
        return _E_base2(z, p)
    key = (round(p["Om"], 6), round(p["h"], 6), round(p["lam"], 5))
    if key not in _SD_CACHE:
        (Ng, h2, _, _), _ = sd_table(*key)
        _SD_CACHE.clear(); _SD_CACHE[key] = (Ng, np.sqrt(h2))
    Ng, Hg = _SD_CACHE[key]
    Or = OMEGA_G_H2 * (1 + 0.2271 * NEFF) / p["h"]**2
    Ez = np.asarray(z, float); Nz = -np.log1p(Ez)
    out = np.interp(Nz, Ng, Hg)
    early = Nz < N0                                    # before the table: field frozen ⇒ ΛCDM-like
    if np.any(early):
        OL = 1 - p["Om"] - Or
        out = np.where(early, np.sqrt(p["Om"] * (1 + Ez)**3 + Or * (1 + Ez)**4 + OL), out)
    return out

def chi2_sd(x):
    Om, h, wb, lam = x
    if not (0.05 < Om < 0.7 and 0.4 < h < 1 and 0 <= lam < 3): return 1e30
    v = total_chi2({"model": "sdriver", "Om": Om, "h": h, "wb": wb, "lam": lam}, ("SN", "BAO", "CMB"))
    return v if np.isfinite(v) else 1e30

refL = fit_cosmo("lcdm", ("SN", "BAO", "CMB")); pL = refL["params"]
# profile in λ (λ ≥ 0 by construction: a real field with α_S > 0)
lam_grid = np.round(np.arange(0.0, 1.61, 0.2), 3); prof_sd = []; xs = [pL["Om"], pL["h"], pL["wb"]]
for lam in lam_grid:
    r_ = minimize(lambda x: chi2_sd([*x, lam]), xs, method="Nelder-Mead", options={"xatol": 1e-5, "fatol": 1e-3, "maxiter": 400})
    xs = list(r_.x); prof_sd.append((float(lam), float(r_.fun - refL["chi2"]), list(map(float, r_.x))))
# reference = λ = 0 of the same code (identical to ΛCDM up to interpolation), so Δχ² measures λ alone
ref0 = prof_sd[0][1]; prof_sd = [(l_, d_ - ref0, x_) for l_, d_, x_ in prof_sd]
print(f"    (λ = 0 vs the ΛCDM module: {ref0:+.2f}, interpolation offset removed)")
best = min(prof_sd, key=lambda t_: t_[1])
for lam, d, _ in prof_sd: print(f"    λ = {lam:.1f}   Δχ² = {d:+7.2f}")
dAIC_sd = best[1] + 2
lam_ok = [lam for lam, d, _ in prof_sd if d - best[1] < 4]
record("SD1", "TEST", "S(t) driver with GM's own potential (V ∝ M_p²μ² ⇒ exponential), one new number λ",
       f"best λ = {best[0]:.1f}, Δχ² = {best[1]:+.2f}, ΔAIC = {dAIC_sd:+.2f}; λ ≤ {max(lam_ok):.1f} at 2σ",
       rule="ΔAIC < 4", passed=bool(dAIC_sd < 4))
# w(z) of the best fit
Om_b, h_b, wb_b = best[2]
(Ng, h2g, phg, dphg), v0b = sd_table(Om_b, h_b, best[0])
rho_phi = h2g * dphg**2 / 2 + 3 * v0b * np.exp(-best[0] * phg)
p_phi = h2g * dphg**2 / 2 - 3 * v0b * np.exp(-best[0] * phg)
w_today = float(p_phi[-1] / rho_phi[-1])
i1 = np.argmin(abs(Ng - math.log(0.5)))
w_z1 = float(p_phi[i1] / rho_phi[i1])
wD5 = COSMO["SN+BAO+CMB"]["w0wa"]["params"] if "COSMO" in globals() else None
record("SD2", "DIAGNOSTIC", "Equation of state of the S(t) driver (never below −1, I.8)",
       f"w(z=0) = {w_today:+.3f}, w(z=1) = {w_z1:+.3f}" + (f"; CPL fit prefers w0 = {wD5['w0']:+.2f}, wa = {wD5['wa']:+.2f} (crosses −1)" if wD5 else ""),
       note="A thawing field: frozen like Λ at early times, rolling today. It reproduces w0 > −1 but cannot cross −1 as the CPL fit does.")
record("SD3", "DERIVED", "The cosmic slice does not settle: V ∝ e^{−λφ} has no minimum",
       f"late-time attractor w → −1 + λ²/3 = {-1 + best[0]**2 / 3:+.3f} (λ = {best[0]:.1f}); vacuum keeps decaying",
       note="'Why is the vacuum constant' is answered with 'it is not, quite' — consistent with the data only because λ is small.")
record("SD4", "DIAGNOSTIC", "Initial condition of the S(t) driver",
       f"field frozen at early times with V = {v0b:.3f} × ρ_crit,0",
       note="The starting value is today's dark-energy density, so the driver does not remove the 'why now' coincidence; "
            "it moves it into the initial condition.")
record("CE3", "DIAGNOSTIC", "GM's own late-time dynamics reach the ceiling behaviour",
       f"best λ = {best[0]:.1f}: w → {-1 + best[0]**2 / 3:+.3f} > −1 at late times, so ρ_DE → 0 as a → ∞",
       note="Consistent with Λ_eff → 0 at the ceiling.")
E = _E_base2
SD = {"profile": prof_sd, "best_lambda": best[0], "w0": w_today, "w_z1": w_z1}
(RES / "section07c_s_driver.json").write_text(json.dumps(SD, indent=2, default=float))
