# The Physical Plane — test suite

Code behind *The Physical Plane: a five-coordinate (x, y, z, t, S) mapping of morfs, selectors and replicators*.

Running the suite produces 73 labelled results. Each is one of:

| Kind | Meaning |
| --- | --- |
| DERIVED | a symbolic identity of the geometry, checked by computer algebra |
| TEST | a pass rule fixed before running; data can falsify the claim |
| MEASUREMENT | a number measured once from data and then held fixed |
| CONSTRAINT | a bound on a parameter, no pass/fail |
| DIAGNOSTIC | a computed number with no pass/fail rule |
| PROPOSED | a prediction stated in the code (g†(z) = cH(z)/2π, P1), tested in Z1–Z5 |
| SUPERSEDED | an earlier formulation, kept with its pre-set rule and outcome |

No verdict is hardcoded and nothing the code computes is discarded. The two SUPERSEDED entries are earlier formulations that failed their rules and were replaced: the original preprint's linear galaxy law (T1b, replaced by the vacuum-gradient field GF1–GF3) and a single vacuum curve through all four vacuum values (VS3, replaced by the geometric vacuum I.11 plus the sign flip SG1).

| Cell | Paper section |
| --- | --- |
| `p01_setup.py` | Data download (with checksums) and the result registry |
| `p02_geometry.py` | §3 The geometry behind the map |
| `p03_map.py` | §2 The map: morfs, the Selector and replicators along S |
| `p04_galactic_gradient.py` | §5 The galactic region: the vacuum-gradient field on SPARC |
| `p04b_clusters.py` | §5.2 Groups and clusters: galaxies' Darkness, hot plasma, X-COP / kinematic clusters / X-ray groups / central cluster galaxies |
| `p05_vacuum_along_S.py` | §4 The vacuum along the map, the sign flip; cosmology likelihoods used in §6–§7 |
| `p06_top_of_map.py` | §6 The fading vacuum (SN, BAO, CMB, chronometers; S(t)) |
| `p07_null_tests.py` | §7 Null tests |
| `p08_redshift.py` | §5 Redshift test of the galactic scale (four high-redshift samples) |
| `p09_summary.py` | Writes every result to `results/` |

```
pip install -r requirements.txt
python run_all.py                     # writes results/paper_results.json
python build_notebook.py notebook/The_Physical_Plane.ipynb
```

Data are public and downloaded on the first run: SPARC (Lelli, McGaugh & Schombert 2016), Pantheon+ (Brout et al. 2022), DESI DR2 BAO, Planck 2018 distance priors, BOSS DR12 fσ8, the cosmic-chronometer H(z) compilation, X-COP cluster profiles (Eckert et al. 2022) and cluster kinematic masses (Li et al. 2023). Group fits (Gastaldello et al. 2007), cluster star masses (Kravtsov et al. 2018; Eckert et al. 2022) and the MaNGA central-galaxy relation (Tian et al. 2024) are entered from the published tables in `p04b_clusters.py`.



High-redshift rows used by `p08_redshift.py` are in `data_included/highz/`: Price et al. 2021 (Tables 1 and 3) and the KROSS, KMOS3D and KGES dark-matter-fraction catalogues (Zenodo record 15458539; KROSS = first 42 rows of the catalogue). Each catalogue row was checked against the catalogue's own f_DM (largest mismatch 0.04).
