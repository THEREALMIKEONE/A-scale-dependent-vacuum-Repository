"""Run every cell and write an executed notebook. Usage: python build_notebook.py out.ipynb"""
import os, sys, io, contextlib, nbformat as nbf
HERE = os.path.dirname(os.path.abspath(__file__))
SECTIONS = [("p01_setup", "Setup and data"), ("p02_geometry", "§3 The geometry behind the map"),
            ("p03_map", "§2 The map: morfs, the Selector and replicators along S"),
            ("p04_galactic_gradient", "§5 The galactic region: the vacuum gradient"), ("p04b_clusters", "§5.2 Groups and clusters"),
            ("p05_vacuum_along_S", "§4 The vacuum along the map"), ("p06_top_of_map", "§6 The top of the map: the fading vacuum"),
            ("p07_null_tests", "§7 Null tests"), ("p08_redshift", "§5 Redshift test of the galactic scale"), ("p09_summary", "All results")]
nb = nbf.v4.new_notebook(); G = {}; n = 1
nb.cells.append(nbf.v4.new_markdown_cell("# The Physical Plane\n*A five-coordinate (x, y, z, t, S) mapping of morfs, selectors and replicators* — test suite"))
for name, title in SECTIONS:
    nb.cells.append(nbf.v4.new_markdown_cell("## " + title))
    src = open(os.path.join(HERE, "cells", name + ".py"), encoding="utf-8").read(); buf = io.StringIO()
    with contextlib.redirect_stdout(buf): exec(compile(src, name, "exec"), G)
    c = nbf.v4.new_code_cell(src, execution_count=n); c.outputs = [nbf.v4.new_output("stream", name="stdout", text=buf.getvalue())]
    nb.cells.append(c); n += 1; print("ran", name, file=sys.stderr)
nb.metadata["kernelspec"] = {"name": "python3", "display_name": "Python 3", "language": "python"}
nbf.write(nb, sys.argv[1])
